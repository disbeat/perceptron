%%%%
%  Computa��o Adaptativa
%  Trabalho Pr�tico 1
%
%  Grupo 10
%   - S�rgio Santos - 2006125508
%
%  25/09/2009
%%%%
function p = calcRect(W,B)
% Calculate the weights rect (line)
    p = [ -W(1)/W(2) -B/W(2) ];
end