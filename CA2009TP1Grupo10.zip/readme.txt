-------------------------------

  Computa��o Adaptativa

  Trabalho Pr�tico 1

  Grupo 10
   - S�rgio Santos - 2006125508

  25/09/2009

-------------------------------

Para executar o trabalho, correr a fun��o tp1.m

Ir� demonstrar gr�ficamente a converg�ncia dos pesos para 3 neur�nios do percept�o:

 N1 - AND
 N2 - OR
 N3 - NAND + OR

E no final, a correcta classifica��o do caso XOR, utilizando esses mesmos 3 neur�nios.